==============================
ALOA Version 3.1.0 Readme File
==============================

Please read this file carefully before using ALOA.

Copyright
---------

This software is free software according to the GNU General Public 
License (GPL). You must read and accept the contents of the file 
license.txt that is provided with this release before you use this 
software. 

Copyright 2003-2004 by PERA Software Solutions GmbH.


Contents
--------

This distribution contains:

- ALOA's source code (.\*.cpp, .\*.h)
- ALOA's Visual Studio project files (.\aloa.dsp and .\aloa.dsw for
  VC60 and .\aloa.vcproj and .\aloa.sln for .NET, respectively)
- ALOA's pre-built executable (.\release\aloa.exe)
- dsplinter.bat (.\dsplinter\dsplinter.bat) (VC60)
- vcprojlinter.bat (.\vcprojlinter\vcprojlinter.bat) (VC.NET)
- A document that gives an overview of ALOA's use, design and 
  implementation (.\aloa.pdf)


Requirements
------------

This distribution has been developed under/for Visual C++ 6.0 and 
Visual C++ .NET 2003. To run ALOA as is, you need to have PC-Lint 8.x
installed on your machine. Only PC-Lint 8.x is able to produce flat,
context-free XML output.


Installation
------------

ALOA doesn't need to be installed. However, in order to use dsplinter
or vcprojlinter, you need to define two environment variables:
LINTNT_EXE_PATH // path to the dir where lint-nt.exe resides
ALOA_EXE_PATH   // path to the dir where aloa.exe resides
In addition, you may want to adapt the include path settings in
.\policy.lnt; see below.


How to use ALOA
---------------

ALOA needs the output from a project-wide Lint session as input. Running 
ALOA is a multi-staged process (1. obtaining project settings, 2. running 
Lint, 3. running ALOA) which is driven by dsplinter/vcprojlinter. 

To use dsplinter/vcprojlinter, change to the directory in which dsplinter/
vcprojlinter resides and invoke it like this:

VC60:   dsplinter c:\dev\myproject\myproject.dsp -default -aloa
VC.NET: vcprojlinter c:\dev\myproject\myproject.vcproj -default -aloa

myproject.dsp/.vcproj is the Visual C++ project that you want to analyze.
-default instructs dsplinter/vcprojlinter to take the default project 
configuration of the project. You can select a particular configuration 
by passing its name instead of -default:

VC60:   dsplinter c:\xxx\myproject.dsp "myproject - Win32 Release" -aloa
VC.NET: vcprojlinter c:\xxx\myproject.vcproj "Release" -aloa

=== [NOTE] ================================================================
dsplinter/vcprojlinter expects a Lint policy file named policy.lnt at the
same directory level as your .dsp/.vcproj file. You can take the policy.lnt
file that comes with ALOA as a basis for your own project policies but make
sure you adapt at least the Visual C++ include file path settings.  
===========================================================================

To ensure that ALOA is set up correctly, you should run ALOA on its own 
source code by executing dogfood.bat. 

There shouldn't be any Lint issues, that is, "Total number of issues found"
should be zero. If you want to get some real output, set the warning level 
in project.lnt to 4:

...
-w4       
-wlib(4)
...


Using dsplinter to lint modules from within VC60
------------------------------------------------

It is possible to integrate dsplinter with the Visual Studio IDE. This enables
you to conveniently lint individual code modules and browse all of the 
contained Lint issues, similar to the way you browse compiler errors/warnings.

Here is how you do it:

- In the Visual Studio menu, select "Tools" -> "Customize..."
- In the tabbed pane, choose the "Tools" tab
- Click on the square icon to add a new tool
- Provide dsplinter as a name
- In the "Command" field specify the fully qualified path to dsplinter.bat
  E. g. m:\dev\aloa\dsplinter\dsplinter.bat
- In the "Arguments" field put this:
  $(WkspDir)\$(WkspName).dsp -default $(FilePath)
- Put the directory in which dsplinter.bat is located in the "Initial Directory"
  field:
  E. g. m:\dev\aloa\dsplinter
- Select "Use output window"
- Close the dialog box

You will find a new entry "dplinter" in the "Tools" menu. Select this command 
to run PC-Lint on the currently active .c/.cpp source file.


Using vcprojlinter to lint modules from within VC.NET
-----------------------------------------------------

Integrating vcprojlinter with VC.NET is similar to the procedure described for 
VC60. However:

- Instead of "dsp" think/use "vcproj"
- "Arguments" field must contain:
  $(ProjectDir)$(ProjectFileName) -default $(ItemPath)<blank> 
  Note! It is important that the "Arguments" field ends with a blank (space);
  that is, replace <blank> with a real blank.



