///////////////////////////////////////////////////////////////////////////////
// ALOA - A Lint Output Analyzer
// Copyright (C) 2003 - 2004 PERA Software Solutions GmbH
// Written by Ralf Holly (rholly@pera-software.com)
// 
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
///////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "globals.h"

using namespace std;

static const std::string VERSION   = "3.1.0"; // ALOA version number
const int MAX_ISSUE_NUMBER         = 2000;    // Highest possible lint issue number
const int UNUSED_ISSUE_NUMBER      = 0;       // Sentinel marker value
const std::string COPYRIGHT        =
    "ALOA version " + VERSION + ".\n"                                        
    "Copyright (c) 2003 - 2004 PERA Software Solutions GmbH.\n"                     
    "Written by Ralf Holly (rholly@pera-software.com).\n";                     
const std::string COPYLEFT         =
    "This program is free software according to the GNU\n"
    "General Public License and comes WITHOUT ANY WARRANTY.\n" 
    "For details, run aloa without arguments.\n";                      

const char* gpLintOutputFile;         
int gSeverityScore = 0;
int gIssuesCount = 0;
ISSUETYPE_LIST gIssueTypeList;
FILE_MAP gFileMap;
ISSUE_MAP gIssueMap;
FILE_LIST gFileList;
ISSUE_LIST gIssueList;
 
void initGlobals(void) {
    // Register types of issues and their severity level
    gIssueTypeList.push_back(IssueType("Elective note",       1, 900, 999));
    gIssueTypeList.push_back(IssueType("Informational",       2, 700, 899));
    gIssueTypeList.push_back(IssueType("Warning",             3, 400, 699));
    gIssueTypeList.push_back(IssueType("Syntax error",        4,   1, 199));
    gIssueTypeList.push_back(IssueType("PC-Lint error",     999, 200, 399));
}

// Determines the severity level of a lint issue
int getSeverity(int number) {
    extern void reportIllegalLintIssueNumber(void);
    // C++ issue numbers have an offset of 1000 compared to C issue numbers.
    // However, the severity levels are identical
    if (number >= 1000)
        number -= 1000;
    
    ISSUETYPE_LIST::iterator iter = gIssueTypeList.begin();
    for (; iter != gIssueTypeList.end(); ++iter) {
        if ((*iter).isThisIssueType(number)) {
            return (*iter).getSeverity();
        }
    }

    reportIllegalLintIssueNumber();
    return -1; // dummy, unreachable
}




